package com.vampiremod.entity;

import com.vampiremod.VampireMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {

    public static EntityType<VampireVillagerEntity> VAMPIRE_VILLAGER;

    public static void register() {
        VAMPIRE_VILLAGER = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(VampireMod.MOD_ID, "vampire_villager"),
            FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, VampireVillagerEntity::new)
                .dimensions(EntityDimensions.fixed(0.6f, 1.95f))
                .build()
        );

        // Attribute kayıt
        FabricDefaultAttributeRegistry.register(
            VAMPIRE_VILLAGER,
            VampireVillagerEntity.createVampireVillagerAttributes()
        );

        VampireMod.LOGGER.info("ModEntities registered.");
    }
}
