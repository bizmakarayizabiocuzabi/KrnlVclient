package com.vampiremod.entity;

import com.vampiremod.component.VampireComponents;
import com.vampiremod.sound.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.UUID;

public class VampireVillagerEntity extends HostileEntity {

    // Komut tipleri
    public static final int CMD_DRINK_BLOOD = 0;
    public static final int CMD_BRING_BLOOD = 1;
    public static final int CMD_TRANSFORM = 2;
    public static final int CMD_ATTACK = 3;

    private UUID ownerUUID;

    public VampireVillagerEntity(EntityType<? extends VampireVillagerEntity> entityType, World world) {
        super(entityType, world);
    }

    public static DefaultAttributeContainer.Builder createVampireVillagerAttributes() {
        return HostileEntity.createHostileAttributes()
            .add(EntityAttributes.MAX_HEALTH, 30.0)
            .add(EntityAttributes.ATTACK_DAMAGE, 5.0)
            .add(EntityAttributes.MOVEMENT_SPEED, 0.35)
            .add(EntityAttributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.2, false));
        this.goalSelector.add(3, new WanderAroundFarGoal(this, 0.8));
        this.goalSelector.add(4, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(5, new LookAroundGoal(this));

        // Köylüleri hedef al
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, VillagerEntity.class, false));
    }

    public void setOwner(ServerPlayerEntity player) {
        this.ownerUUID = player.getUuid();
    }

    public PlayerEntity getOwner() {
        if (ownerUUID == null || getWorld().isClient) return null;
        return getWorld().getPlayerByUuid(ownerUUID);
    }

    public boolean isOwner(PlayerEntity player) {
        if (player == null || ownerUUID == null) return false;
        return player.getUuid().equals(ownerUUID);
    }

    public void receiveCommand(ServerPlayerEntity commander, int commandType) {
        if (!isOwner(commander)) {
            commander.sendMessage(Text.literal("Bu vampir köylü sana itaat etmiyor!").formatted(Formatting.RED), false);
            return;
        }

        switch (commandType) {
            case CMD_ATTACK -> {
                VillagerEntity target = findNearestVillager();
                if (target != null) {
                    this.setTarget(target);
                    commander.sendMessage(Text.literal("Vampir Köylü: 'Anlaşıldı efendim, saldırıyorum!'").formatted(Formatting.DARK_RED), false);
                } else {
                    commander.sendMessage(Text.literal("Yakında hedef yok.").formatted(Formatting.GRAY), false);
                }
            }
            case CMD_BRING_BLOOD -> {
                commander.sendMessage(Text.literal("Vampir Köylü: 'Efendim, kan getiriyorum!'").formatted(Formatting.DARK_RED), false);
                getWorld().playSound(null, getBlockPos(), ModSounds.VAMPIRE_HISS, SoundCategory.NEUTRAL, 1.0f, 0.8f);
            }
            case CMD_DRINK_BLOOD -> {
                commander.sendMessage(Text.literal("Vampir Köylü: 'Efendim, kanınızı içeyim mi?'").formatted(Formatting.DARK_PURPLE), false);
            }
            case CMD_TRANSFORM -> {
                commander.sendMessage(Text.literal("Vampir Köylü: 'Efendim, onu vampir yapayım mı?'").formatted(Formatting.DARK_PURPLE), false);
            }
        }
    }

    @Override
    public void attack(LivingEntity target, float pullProgress) {
        super.attack(target, pullProgress);
        PlayerEntity owner = getOwner();
        if (owner != null && target instanceof VillagerEntity) {
            owner.sendMessage(
                Text.literal("🧛 Vampir Köylü: 'Efendim! Kanını içeyim mi? Sanamı getireyim? Vampirmi yapayım?'")
                    .formatted(Formatting.DARK_RED),
                false
            );
        }
    }

    private VillagerEntity findNearestVillager() {
        return getWorld().getClosestEntity(
            VillagerEntity.class,
            null,
            null,
            this,
            32.0,
            entity -> true
        );
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        // Güneşte yan
        if (this.getWorld().isDay() && !this.getWorld().isClient) {
            if (this.getWorld().isSkyVisibleAllowingSnow(this.getBlockPos())) {
                this.setOnFireFor(1);
            }
        }
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        if (ownerUUID != null) {
            nbt.putUuid("OwnerUUID", ownerUUID);
        }
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.containsUuid("OwnerUUID")) {
            ownerUUID = nbt.getUuid("OwnerUUID");
        }
    }
}
