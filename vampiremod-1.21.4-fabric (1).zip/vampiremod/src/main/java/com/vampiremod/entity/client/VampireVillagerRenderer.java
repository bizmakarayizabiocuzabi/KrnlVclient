package com.vampiremod.entity.client;

import com.vampiremod.VampireMod;
import com.vampiremod.entity.VampireVillagerEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.VillagerResemblingModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public class VampireVillagerRenderer extends MobEntityRenderer<VampireVillagerEntity, VillagerResemblingModel<VampireVillagerEntity>> {

    private static final Identifier TEXTURE = Identifier.of(VampireMod.MOD_ID, "textures/entity/vampire_villager.png");

    public VampireVillagerRenderer(EntityRendererFactory.Context context) {
        super(context, new VillagerResemblingModel<>(context.getPart(EntityModelLayers.VILLAGER)), 0.5f);
    }

    @Override
    public Identifier getTexture(VampireVillagerEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(VampireVillagerEntity entity, float yaw, float tickDelta,
                       MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }
}
