package com.vampiremod.mixin;

import com.vampiremod.VampireModClientData;
import com.vampiremod.entity.VampireVillagerEntity;
import com.vampiremod.screen.VampireCommandScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(ClientPlayerInteractionManager.class)
public class PlayerInteractMixin {

    @Inject(method = "interactEntity", at = @At("HEAD"), cancellable = true)
    private void onInteractEntity(PlayerEntity player, Entity entity, Hand hand,
                                   CallbackInfoReturnable<ActionResult> cir) {
        if (entity instanceof VampireVillagerEntity && VampireModClientData.isVampire) {
            MinecraftClient.getInstance().setScreen(new VampireCommandScreen(entity.getId()));
            cir.setReturnValue(ActionResult.SUCCESS);
        }
    }
}
