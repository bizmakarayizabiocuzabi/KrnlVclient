package com.vampiremod.mixin;

import com.vampiremod.component.VampireComponents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntity.class)
public class PlayerTickMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void onPlayerTick(CallbackInfo ci) {
        PlayerEntity player = (PlayerEntity)(Object)this;

        // Yalnızca server-side
        if (player.getWorld().isClient) return;
        if (!(player instanceof ServerPlayerEntity serverPlayer)) return;
        if (!VampireComponents.isVampire(serverPlayer)) return;

        ServerWorld serverWorld = serverPlayer.getServerWorld();

        // Güneş hasarı - her 20 tick (1 sn)
        if (player.age % 20 == 0) {
            boolean isDaytime = serverWorld.isDay();
            boolean isSkyVisible = serverWorld.isSkyVisibleAllowingSnow(player.getBlockPos());
            boolean isRaining = serverWorld.isRaining();
            boolean hasHelmet = !player.getInventory().getArmorStack(3).isEmpty();

            if (isDaytime && isSkyVisible && !isRaining && !player.isSubmergedInWater()) {
                player.setOnFireFor(1);
                player.damage(serverWorld.getDamageSources().inFire(), 1.0f);
            }
        }
    }
}
