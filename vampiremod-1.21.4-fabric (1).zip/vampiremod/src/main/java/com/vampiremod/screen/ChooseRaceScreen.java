package com.vampiremod.screen;

import com.vampiremod.network.VampireNetworking;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public class ChooseRaceScreen extends Screen {

    public ChooseRaceScreen() {
        super(Text.literal("Irk Secimi"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;

        // İnsan butonu
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("  Insan Kal  "),
            btn -> chooseRace(false)
        ).dimensions(cx - 125, cy + 40, 115, 28).build());

        // Vampir butonu
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("  Vampir Ol  "),
            btn -> chooseRace(true)
        ).dimensions(cx + 10, cy + 40, 115, 28).build());
    }

    private void chooseRace(boolean vampire) {
        VampireNetworking.sendSetRace(vampire);
        this.close();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Koyu arka plan
        this.renderBackground(context, mouseX, mouseY, delta);

        int cx = this.width / 2;
        int cy = this.height / 2;

        // Panel arka planı
        int pw = 290, ph = 170;
        context.fill(cx - pw/2, cy - ph/2, cx + pw/2, cy + ph/2, 0xDD0D0010);
        context.drawBorder(cx - pw/2 - 1, cy - ph/2 - 1, pw + 2, ph + 2, 0xFF8B0000);
        context.drawBorder(cx - pw/2 - 2, cy - ph/2 - 2, pw + 4, ph + 4, 0xFF440000);

        // Dekoratif üst çizgi
        context.fill(cx - pw/2 + 10, cy - ph/2 + 22, cx + pw/2 - 10, cy - ph/2 + 23, 0xFF6B0000);

        // Başlık
        context.drawCenteredTextWithShadow(textRenderer,
            Text.literal("⚰  IRK SECIMI  ⚰"), cx, cy - ph/2 + 8, 0xFFDD0000);

        // Alt başlık
        context.drawCenteredTextWithShadow(textRenderer,
            Text.literal("Kim olmak istiyorsun?"), cx, cy - ph/2 + 28, 0xFFCCCCCC);

        // Orta ayraç
        context.fill(cx - 1, cy - ph/2 + 40, cx + 1, cy + 30, 0xFF440000);

        // === İNSAN TARAFI ===
        context.drawCenteredTextWithShadow(textRenderer,
            Text.literal("INSAN"), cx - 65, cy - 30, 0xFF88AAFF);

        String[] humanLines = {
            "Normal hayat",
            "Gunde serbestce",
            "gezer",
            "Gunes zararsiz",
        };
        for (int i = 0; i < humanLines.length; i++) {
            context.drawCenteredTextWithShadow(textRenderer,
                Text.literal(humanLines[i]), cx - 65, cy - 16 + i * 10, 0xFF999999);
        }

        // === VAMPİR TARAFI ===
        context.drawCenteredTextWithShadow(textRenderer,
            Text.literal("VAMPiR"), cx + 65, cy - 30, 0xFFDD0000);

        String[] vampLines = {
            "Kan metresi var",
            "3 dakikada bir",
            "kan icmen gerek",
            "Gunes yakar!",
            "Koyluyu isirir",
            "vampir yaparsın"
        };
        for (int i = 0; i < vampLines.length; i++) {
            context.drawCenteredTextWithShadow(textRenderer,
                Text.literal(vampLines[i]), cx + 65, cy - 16 + i * 10, 0xFF999999);
        }

        // Kan damlaları dekorasyonu
        for (int i = 0; i < 7; i++) {
            int dropX = cx - pw/2 + 15 + i * 38;
            context.fill(dropX, cy - ph/2, dropX + 2, cy - ph/2 + 8, 0xFFAA0000);
            context.fill(dropX + 1, cy - ph/2 + 8, dropX + 2, cy - ph/2 + 12, 0xFF880000);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
