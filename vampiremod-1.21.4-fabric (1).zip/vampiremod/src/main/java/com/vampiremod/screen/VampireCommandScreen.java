package com.vampiremod.screen;

import com.vampiremod.entity.VampireVillagerEntity;
import com.vampiremod.network.VampireNetworking;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public class VampireCommandScreen extends Screen {

    private final int entityId;

    public VampireCommandScreen(int entityId) {
        super(Text.literal("Vampir Koylü Komutlari"));
        this.entityId = entityId;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("⚔  Saldır (En yakın köylüye)"),
            btn -> sendCmd(VampireVillagerEntity.CMD_ATTACK)
        ).dimensions(cx - 110, cy - 32, 220, 22).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("🩸  Kanını İçeyim mi?"),
            btn -> sendCmd(VampireVillagerEntity.CMD_DRINK_BLOOD)
        ).dimensions(cx - 110, cy - 7, 220, 22).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("🧪  Kan Getir Bana"),
            btn -> sendCmd(VampireVillagerEntity.CMD_BRING_BLOOD)
        ).dimensions(cx - 110, cy + 18, 220, 22).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("🧛  Bir Köylüyü Vampir Yap"),
            btn -> sendCmd(VampireVillagerEntity.CMD_TRANSFORM)
        ).dimensions(cx - 110, cy + 43, 220, 22).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("✖  İptal"),
            btn -> this.close()
        ).dimensions(cx - 55, cy + 74, 110, 20).build());
    }

    private void sendCmd(int cmd) {
        VampireNetworking.sendVampireCommand(entityId, cmd);
        this.close();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        int cx = this.width / 2;
        int cy = this.height / 2;

        int pw = 250, ph = 170;
        context.fill(cx - pw/2, cy - ph/2, cx + pw/2, cy + ph/2, 0xDD150000);
        context.drawBorder(cx - pw/2 - 1, cy - ph/2 - 1, pw + 2, ph + 2, 0xFF8B0000);

        context.drawCenteredTextWithShadow(textRenderer,
            Text.literal("🧛 VAMPiR KOYLÜ"), cx, cy - ph/2 + 8, 0xFFDD0000);
        context.drawCenteredTextWithShadow(textRenderer,
            Text.literal("Ne yapmami istersiniz, efendim?"), cx, cy - ph/2 + 22, 0xFFAAAAAA);

        context.fill(cx - pw/2 + 8, cy - ph/2 + 34, cx + pw/2 - 8, cy - ph/2 + 35, 0xFF550000);

        super.render(context, mouseX, mouseY, delta);
    }
}
