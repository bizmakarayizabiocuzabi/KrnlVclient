package com.vampiremod.network;

import com.vampiremod.VampireMod;
import com.vampiremod.VampireModClientData;
import com.vampiremod.component.VampireComponents;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class VampireNetworking {

    // ===================== Payload sınıfları =====================

    /** Sunucudan istemciye: vampir durumu + kan miktarı */
    public record VampireDataPayload(boolean isVampire, float bloodMeter) implements CustomPayload {
        public static final Id<VampireDataPayload> ID =
            new Id<>(Identifier.of(VampireMod.MOD_ID, "vampire_data"));
        public static final PacketCodec<PacketByteBuf, VampireDataPayload> CODEC =
            PacketCodec.of(
                (val, buf) -> { buf.writeBoolean(val.isVampire()); buf.writeFloat(val.bloodMeter()); },
                buf -> new VampireDataPayload(buf.readBoolean(), buf.readFloat())
            );
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** İstemciden sunucuya: ırk seçimi */
    public record SetRacePayload(boolean vampire) implements CustomPayload {
        public static final Id<SetRacePayload> ID =
            new Id<>(Identifier.of(VampireMod.MOD_ID, "set_race"));
        public static final PacketCodec<PacketByteBuf, SetRacePayload> CODEC =
            PacketCodec.of(
                (val, buf) -> buf.writeBoolean(val.vampire()),
                buf -> new SetRacePayload(buf.readBoolean())
            );
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** İstemciden sunucuya: vampir köylüye komut */
    public record VampireCommandPayload(int entityId, int commandType) implements CustomPayload {
        public static final Id<VampireCommandPayload> ID =
            new Id<>(Identifier.of(VampireMod.MOD_ID, "vampire_command"));
        public static final PacketCodec<PacketByteBuf, VampireCommandPayload> CODEC =
            PacketCodec.of(
                (val, buf) -> { buf.writeInt(val.entityId()); buf.writeInt(val.commandType()); },
                buf -> new VampireCommandPayload(buf.readInt(), buf.readInt())
            );
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    // ===================== Kayıt (Server tarafı) =====================

    public static void registerServerPackets() {
        // S2C
        PayloadTypeRegistry.playS2C().register(VampireDataPayload.ID, VampireDataPayload.CODEC);
        // C2S
        PayloadTypeRegistry.playC2S().register(SetRacePayload.ID, SetRacePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(VampireCommandPayload.ID, VampireCommandPayload.CODEC);

        // Irk seçimi al
        ServerPlayNetworking.registerGlobalReceiver(SetRacePayload.ID, (payload, ctx) -> {
            ServerPlayerEntity player = ctx.player();
            ctx.server().execute(() -> VampireComponents.setVampire(player, payload.vampire()));
        });

        // Vampir köylü komutu al
        ServerPlayNetworking.registerGlobalReceiver(VampireCommandPayload.ID, (payload, ctx) -> {
            ServerPlayerEntity player = ctx.player();
            ctx.server().execute(() -> {
                if (player.getServerWorld().getEntityById(payload.entityId())
                        instanceof com.vampiremod.entity.VampireVillagerEntity vampVillager) {
                    vampVillager.receiveCommand(player, payload.commandType());
                }
            });
        });
    }

    // ===================== Kayıt (Client tarafı) =====================

    @Environment(EnvType.CLIENT)
    public static void registerClientPackets() {
        ClientPlayNetworking.registerGlobalReceiver(VampireDataPayload.ID, (payload, ctx) -> {
            ctx.client().execute(() -> {
                VampireModClientData.isVampire = payload.isVampire();
                VampireModClientData.clientBloodMeter = payload.bloodMeter();
            });
        });
    }

    // ===================== Gönderme yardımcıları =====================

    public static void sendVampireDataToClient(ServerPlayerEntity player, boolean isVampire, float bloodMeter) {
        ServerPlayNetworking.send(player, new VampireDataPayload(isVampire, bloodMeter));
    }

    @Environment(EnvType.CLIENT)
    public static void sendSetRace(boolean vampire) {
        ClientPlayNetworking.send(new SetRacePayload(vampire));
    }

    @Environment(EnvType.CLIENT)
    public static void sendVampireCommand(int entityId, int commandType) {
        ClientPlayNetworking.send(new VampireCommandPayload(entityId, commandType));
    }
}
