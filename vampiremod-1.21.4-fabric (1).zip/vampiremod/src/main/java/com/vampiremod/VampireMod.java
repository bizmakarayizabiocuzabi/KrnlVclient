package com.vampiremod;

import com.vampiremod.component.VampireComponents;
import com.vampiremod.effect.ModEffects;
import com.vampiremod.entity.ModEntities;
import com.vampiremod.item.ModItems;
import com.vampiremod.network.VampireNetworking;
import com.vampiremod.sound.ModSounds;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VampireMod implements ModInitializer {

    public static final String MOD_ID = "vampiremod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Tick sayaçları
    private static int globalTick = 0;
    // 3 dakika = 20 TPS * 60 sn * 3 = 3600 tick
    private static final int BLOOD_DRAIN_INTERVAL = 3600;
    // 1 saniye = 20 tick
    private static final int BLOOD_WARN_INTERVAL = 20;

    @Override
    public void onInitialize() {
        LOGGER.info("=== VampireMod 1.0.0 başlatılıyor ===");

        ModSounds.register();
        ModEffects.register();
        ModItems.register();
        ModEntities.register();
        VampireComponents.register();
        VampireNetworking.registerServerPackets();

        // Server tick olayları
        ServerTickEvents.END_SERVER_TICK.register(VampireMod::onServerTick);

        LOGGER.info("=== VampireMod hazır! ===");
    }

    private static void onServerTick(MinecraftServer server) {
        globalTick++;

        // Her 20 tick (1 sn) - kan uyarısı
        if (globalTick % BLOOD_WARN_INTERVAL == 0) {
            for (ServerWorld world : server.getWorlds()) {
                for (ServerPlayerEntity player : world.getPlayers()) {
                    VampireComponents.checkBloodWarning(player);
                }
            }
        }

        // Her 3600 tick (3 dk) - kan azalt
        if (globalTick % BLOOD_DRAIN_INTERVAL == 0) {
            for (ServerWorld world : server.getWorlds()) {
                for (ServerPlayerEntity player : world.getPlayers()) {
                    VampireComponents.drainBloodMeter(player);
                }
            }
        }
    }
}
