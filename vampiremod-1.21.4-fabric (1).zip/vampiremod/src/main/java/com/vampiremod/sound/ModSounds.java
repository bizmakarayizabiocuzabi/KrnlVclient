package com.vampiremod.sound;

import com.vampiremod.VampireMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {

    public static SoundEvent VAMPIRE_BITE;
    public static SoundEvent VAMPIRE_DRINK_BLOOD;
    public static SoundEvent VAMPIRE_HISS;
    public static SoundEvent VAMPIRE_TRANSFORM;
    public static SoundEvent VAMPIRE_AMBIENT;

    public static void register() {
        VAMPIRE_BITE = registerSound("vampire_bite");
        VAMPIRE_DRINK_BLOOD = registerSound("vampire_drink_blood");
        VAMPIRE_HISS = registerSound("vampire_hiss");
        VAMPIRE_TRANSFORM = registerSound("vampire_transform");
        VAMPIRE_AMBIENT = registerSound("vampire_ambient");
        VampireMod.LOGGER.info("ModSounds registered.");
    }

    private static SoundEvent registerSound(String name) {
        Identifier id = Identifier.of(VampireMod.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }
}
