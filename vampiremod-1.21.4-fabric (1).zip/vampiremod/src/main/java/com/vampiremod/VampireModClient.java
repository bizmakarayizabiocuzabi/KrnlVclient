package com.vampiremod;

import com.vampiremod.client.BloodMeterHud;
import com.vampiremod.client.VampireEffectRenderer;
import com.vampiremod.entity.ModEntities;
import com.vampiremod.entity.client.VampireVillagerRenderer;
import com.vampiremod.network.VampireNetworking;
import com.vampiremod.screen.ChooseRaceScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

@Environment(EnvType.CLIENT)
public class VampireModClient implements ClientModInitializer {

    private static boolean raceScreenOpened = false;

    @Override
    public void onInitializeClient() {
        VampireMod.LOGGER.info("VampireMod Client başlatılıyor...");

        // Ağ paketlerini kaydet
        VampireNetworking.registerClientPackets();

        // HUD kaydet
        HudRenderCallback.EVENT.register(BloodMeterHud::render);

        // Entity renderer
        EntityRendererRegistry.register(ModEntities.VAMPIRE_VILLAGER, VampireVillagerRenderer::new);

        // Baş dönmesi efekti
        ClientTickEvents.END_CLIENT_TICK.register(VampireEffectRenderer::onClientTick);

        // Oyun başında ırk seçim ekranı - oyuncuya ilk dünya yüklendiğinde göster
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player != null
                    && client.currentScreen == null
                    && !raceScreenOpened
                    && !VampireModClientData.isVampire) {
                raceScreenOpened = true;
                client.setScreen(new ChooseRaceScreen());
            }
        });

        VampireMod.LOGGER.info("VampireMod Client yüklendi!");
    }
}
