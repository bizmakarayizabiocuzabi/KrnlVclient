package com.vampiremod.component;

import com.vampiremod.VampireMod;
import com.vampiremod.network.VampireNetworking;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class VampireComponents {

    private static final String KEY_IS_VAMPIRE = "vampiremod_is_vampire";
    private static final String KEY_BLOOD = "vampiremod_blood";
    public static final float MAX_BLOOD = 100.0f;

    public static void register() {
        VampireMod.LOGGER.info("VampireComponents kaydedildi.");
    }

    // --- NBT helpers ---

    public static boolean isVampire(ServerPlayerEntity player) {
        NbtCompound nbt = player.getCustomData();
        return nbt.contains(KEY_IS_VAMPIRE) && nbt.getBoolean(KEY_IS_VAMPIRE);
    }

    public static void setVampire(ServerPlayerEntity player, boolean vampire) {
        NbtCompound nbt = player.getCustomData();
        nbt.putBoolean(KEY_IS_VAMPIRE, vampire);
        if (vampire) {
            nbt.putFloat(KEY_BLOOD, MAX_BLOOD);
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, Integer.MAX_VALUE, 0, false, false));
        }
        syncToClient(player);
    }

    public static float getBloodMeter(ServerPlayerEntity player) {
        NbtCompound nbt = player.getCustomData();
        return nbt.contains(KEY_BLOOD) ? nbt.getFloat(KEY_BLOOD) : MAX_BLOOD;
    }

    public static void setBloodMeter(ServerPlayerEntity player, float amount) {
        NbtCompound nbt = player.getCustomData();
        float clamped = Math.max(0f, Math.min(MAX_BLOOD, amount));
        nbt.putFloat(KEY_BLOOD, clamped);
        syncToClient(player);
    }

    // --- Game logic ---

    /** 3 dakikada bir çağrılır. 20 kan azalt. */
    public static void drainBloodMeter(ServerPlayerEntity player) {
        if (!isVampire(player)) return;
        float cur = getBloodMeter(player);
        setBloodMeter(player, cur - 20f);

        if (getBloodMeter(player) <= 0f) {
            applyBloodStarvation(player);
        }
    }

    /** Her saniye çağrılır: düşük kan uyarısı ve efektler. */
    public static void checkBloodWarning(ServerPlayerEntity player) {
        if (!isVampire(player)) return;
        float blood = getBloodMeter(player);

        if (blood <= 20f && blood > 0f) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 80, 0, false, false));
            if (blood <= 10f) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 80, 0, false, false));
                player.sendMessage(
                    Text.literal("⚠ Kana ihtiyacın var! Bir köylüyü ısır! (" + (int)blood + "/100)")
                        .formatted(Formatting.DARK_RED, Formatting.BOLD),
                    true
                );
            }
        }
    }

    /** Kan dolu, efektleri uygula. */
    public static void feedBlood(ServerPlayerEntity player, float amount) {
        if (!isVampire(player)) return;
        setBloodMeter(player, getBloodMeter(player) + amount);
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 200, 1, false, false));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 200, 0, false, false));
        player.removeStatusEffect(StatusEffects.NAUSEA);
        player.removeStatusEffect(StatusEffects.BLINDNESS);
        player.removeStatusEffect(StatusEffects.DARKNESS);
        syncToClient(player);
    }

    private static void applyBloodStarvation(ServerPlayerEntity player) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 200, 2, false, false));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 200, 0, false, false));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 2, false, false));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 2, false, false));
        player.damage(player.getServerWorld().getDamageSources().starve(), 2.0f);
        player.sendMessage(
            Text.literal("☠ Kansızlıktan ölüyorsun! Hemen bir köylüyü ısır!")
                .formatted(Formatting.DARK_RED, Formatting.BOLD),
            true
        );
    }

    public static void syncToClient(ServerPlayerEntity player) {
        VampireNetworking.sendVampireDataToClient(player, isVampire(player), getBloodMeter(player));
    }
}
