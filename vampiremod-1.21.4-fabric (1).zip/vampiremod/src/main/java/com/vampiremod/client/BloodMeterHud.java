package com.vampiremod.client;

import com.vampiremod.VampireModClientData;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

@Environment(EnvType.CLIENT)
public class BloodMeterHud {

    public static void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null) return;
        if (!VampireModClientData.isVampire) return;
        if (client.options.hudHidden) return;

        int screenWidth = context.getScaledWindowWidth();
        int screenHeight = context.getScaledWindowHeight();

        // Sağ alt köşe konumu
        int x = screenWidth - 115;
        int y = screenHeight - 45;

        float blood = VampireModClientData.clientBloodMeter;
        float ratio = Math.max(0f, Math.min(1f, blood / 100f));

        // === Arka plan ===
        context.fill(x, y, x + 100, y + 12, 0xAA1A0000);
        context.drawBorder(x - 1, y - 1, 102, 14, 0xFF6B0000);

        // === Kan çubuğu rengi ===
        int barColor;
        if (ratio > 0.5f) {
            barColor = 0xFFBB0000;
        } else if (ratio > 0.2f) {
            // Turuncu-kırmızı geçiş
            barColor = 0xFFDD2200;
        } else {
            // Yanıp sönen kritik
            boolean blink = (System.currentTimeMillis() / 350) % 2 == 0;
            barColor = blink ? 0xFFFF0000 : 0xFFFF5500;
        }

        int barWidth = (int)(100 * ratio);
        if (barWidth > 0) {
            context.fill(x, y, x + barWidth, y + 12, barColor);
        }

        // === Kan damlası ikonu (custom pixel art) ===
        drawBloodDrop(context, x - 14, y);

        // === Metin ===
        String txt = (int)blood + " / 100";
        int textX = x + (100 - client.textRenderer.getWidth(txt)) / 2;
        context.drawText(client.textRenderer, txt, textX, y + 2, 0xFFFFFFFF, true);

        // === Başlık ===
        context.drawText(client.textRenderer, "\u00a74\u00a7l\uD83E\uDE78 Kan", x - 14, y - 11, 0xFFCC0000, true);

        // === Düşük kan uyarı overlay ===
        if (ratio <= 0.2f) {
            renderBloodWarningOverlay(context, screenWidth, screenHeight, ratio);
        }

        // === Vampir sembolü ===
        if (VampireModClientData.isVampire) {
            context.drawText(client.textRenderer, "\u00a74\u2620", screenWidth - 12, 5, 0xFFCC0000, true);
        }
    }

    private static void drawBloodDrop(DrawContext ctx, int x, int y) {
        // Piksel sanat kan damlası (10x12)
        int r = 0xFFCC0000;
        int d = 0xFF880000;
        // Üst sivri
        ctx.fill(x+4, y,   x+6, y+2, r);
        // Orta şişkinlik
        ctx.fill(x+2, y+2, x+8, y+6, r);
        ctx.fill(x+1, y+3, x+9, y+8, r);
        // Alt yuvarlak
        ctx.fill(x+2, y+8, x+8, y+11, r);
        ctx.fill(x+3, y+11,x+7, y+12, r);
        // Parlaklık
        ctx.fill(x+3, y+3, x+5, y+5, 0x55FF4444);
        // Gölge
        ctx.fill(x+6, y+7, x+8, y+10, d);
    }

    private static void renderBloodWarningOverlay(DrawContext ctx, int w, int h, float ratio) {
        float pulse = (float)Math.sin(System.currentTimeMillis() / 280.0) * 0.5f + 0.5f;
        int alpha = (int)(pulse * 100 * (1f - ratio * 5f));
        alpha = Math.min(110, Math.max(0, alpha));
        int col = (alpha << 24) | 0x880000;

        int b = 18;
        ctx.fill(0, 0, w, b, col);       // üst
        ctx.fill(0, h-b, w, h, col);     // alt
        ctx.fill(0, b, b, h-b, col);     // sol
        ctx.fill(w-b, b, w, h-b, col);   // sağ
    }
}
