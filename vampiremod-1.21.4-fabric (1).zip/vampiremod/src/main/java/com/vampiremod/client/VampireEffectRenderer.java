package com.vampiremod.client;

import com.vampiremod.VampireModClientData;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

@Environment(EnvType.CLIENT)
public class VampireEffectRenderer {

    private static int tickCount = 0;

    public static void onClientTick(MinecraftClient client) {
        tickCount++;

        if (!VampireModClientData.isVampire) return;
        if (client.player == null) return;

        float blood = VampireModClientData.clientBloodMeter;

        // Düşük kanda baş dönmesi efekti
        if (blood <= 20.0f) {
            VampireModClientData.isDizzy = true;
            VampireModClientData.dizzyTicks = tickCount;

            // Kamera sallama efekti
            if (blood <= 10.0f) {
                applyDizzyEffect(client, blood);
            }
        } else {
            VampireModClientData.isDizzy = false;
        }
    }

    private static void applyDizzyEffect(MinecraftClient client, float blood) {
        if (client.player == null) return;

        // Sinüs dalgasıyla yaw değerini hafifçe değiştir (baş dönmesi)
        double dizzyAmount = (20.0f - blood) / 20.0f;
        float sway = (float) (Math.sin(tickCount * 0.15) * dizzyAmount * 3.0);

        client.player.setYaw(client.player.getYaw() + sway * 0.5f);
    }
}
