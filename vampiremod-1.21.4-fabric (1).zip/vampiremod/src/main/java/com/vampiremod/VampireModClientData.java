package com.vampiremod;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class VampireModClientData {
    public static boolean raceScreenShown = false;
    public static float clientBloodMeter = 100.0f;
    public static boolean isVampire = false;
    public static float bloodWarningAlpha = 0.0f;
    public static boolean isDizzy = false;
    public static int dizzyTicks = 0;
}
