package com.vampiremod.item;

import com.vampiremod.component.VampireComponents;
import com.vampiremod.sound.ModSounds;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class BloodVialItem extends Item {

    public BloodVialItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient) return TypedActionResult.pass(stack);
        if (!(user instanceof ServerPlayerEntity serverPlayer)) return TypedActionResult.pass(stack);

        if (!VampireComponents.isVampire(serverPlayer)) {
            user.sendMessage(Text.literal("Sadece vampirler kan içebilir!").formatted(Formatting.RED), true);
            return TypedActionResult.fail(stack);
        }

        VampireComponents.feedBlood(serverPlayer, 25.0f);
        world.playSound(null, user.getBlockPos(), ModSounds.VAMPIRE_DRINK_BLOOD, SoundCategory.PLAYERS, 1.0f, 1.0f);
        user.sendMessage(Text.literal("🩸 Kan içtin! +25 kan").formatted(Formatting.DARK_RED), true);
        stack.decrement(1);
        return TypedActionResult.success(stack);
    }
}
