package com.vampiremod.item;

import com.vampiremod.component.VampireComponents;
import com.vampiremod.entity.ModEntities;
import com.vampiremod.entity.VampireVillagerEntity;
import com.vampiremod.sound.ModSounds;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class VampireFangsItem extends Item {

    public VampireFangsItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnEntity(ItemStack stack, PlayerEntity player, LivingEntity entity, Hand hand) {
        World world = player.getWorld();
        if (world.isClient) return ActionResult.PASS;

        ServerPlayerEntity serverPlayer = (ServerPlayerEntity) player;
        ServerWorld serverWorld = (ServerWorld) world;

        if (!VampireComponents.isVampire(serverPlayer)) {
            player.sendMessage(Text.literal("Sadece vampirler bunu kullanabilir!").formatted(Formatting.RED), true);
            return ActionResult.FAIL;
        }

        if (entity instanceof VillagerEntity villager) {
            if (player.isSneaking()) {
                transformVillager(serverPlayer, villager, serverWorld);
            } else {
                drinkFromVillager(serverPlayer, villager, serverWorld);
            }
            player.getItemCooldownManager().set(stack.getItem(), 20);
            return ActionResult.SUCCESS;
        }

        if (entity instanceof LivingEntity && !(entity instanceof PlayerEntity)) {
            biteEntity(serverPlayer, entity, serverWorld);
            player.getItemCooldownManager().set(stack.getItem(), 20);
            return ActionResult.SUCCESS;
        }

        return ActionResult.PASS;
    }

    private void drinkFromVillager(ServerPlayerEntity player, VillagerEntity villager, ServerWorld world) {
        world.playSound(null, villager.getBlockPos(), ModSounds.VAMPIRE_BITE, SoundCategory.PLAYERS, 1.0f, 1.0f);
        world.playSound(null, villager.getBlockPos(), ModSounds.VAMPIRE_DRINK_BLOOD, SoundCategory.PLAYERS, 0.8f, 1.0f);
        spawnBloodParticles(world, villager.getPos());
        villager.damage(world.getDamageSources().playerAttack(player), 4.0f);
        VampireComponents.feedBlood(player, 30.0f);
        player.sendMessage(Text.literal("🩸 Kan içtin! +30 kan").formatted(Formatting.DARK_RED), true);
    }

    private void transformVillager(ServerPlayerEntity player, VillagerEntity villager, ServerWorld world) {
        VampireVillagerEntity vampVillager = ModEntities.VAMPIRE_VILLAGER.create(world);
        if (vampVillager == null) return;

        vampVillager.setPosition(villager.getPos());
        vampVillager.setOwner(player);
        villager.discard();
        world.spawnEntity(vampVillager);

        world.playSound(null, vampVillager.getBlockPos(), ModSounds.VAMPIRE_TRANSFORM, SoundCategory.NEUTRAL, 1.0f, 0.8f);
        spawnTransformParticles(world, vampVillager.getPos());

        player.sendMessage(
            Text.literal("🧛 Köylüyü vampir yaptın! Artık sana hizmet edecek. Sağ tıkla komut ver.").formatted(Formatting.DARK_RED),
            false
        );
    }

    private void biteEntity(ServerPlayerEntity player, LivingEntity entity, ServerWorld world) {
        entity.damage(world.getDamageSources().playerAttack(player), 6.0f);
        VampireComponents.feedBlood(player, 15.0f);
        world.playSound(null, entity.getBlockPos(), ModSounds.VAMPIRE_BITE, SoundCategory.PLAYERS, 1.0f, 1.2f);
        spawnBloodParticles(world, entity.getPos());
        player.sendMessage(Text.literal("🩸 Kan içtin! +15 kan").formatted(Formatting.DARK_RED), true);
    }

    private void spawnBloodParticles(ServerWorld world, Vec3d pos) {
        for (int i = 0; i < 12; i++) {
            double dx = (world.random.nextDouble() - 0.5) * 0.5;
            double dy = world.random.nextDouble() * 0.5;
            double dz = (world.random.nextDouble() - 0.5) * 0.5;
            world.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, pos.x, pos.y + 1.0, pos.z, 1, dx, dy, dz, 0.05);
        }
        world.spawnParticles(ParticleTypes.WITCH, pos.x, pos.y + 1.2, pos.z, 8, 0.2, 0.3, 0.2, 0.02);
    }

    private void spawnTransformParticles(ServerWorld world, Vec3d pos) {
        world.spawnParticles(ParticleTypes.WITCH, pos.x, pos.y + 1.0, pos.z, 30, 0.3, 0.5, 0.3, 0.05);
        world.spawnParticles(ParticleTypes.SMOKE, pos.x, pos.y + 0.5, pos.z, 20, 0.3, 0.3, 0.3, 0.02);
        world.spawnParticles(ParticleTypes.LARGE_SMOKE, pos.x, pos.y + 1.0, pos.z, 10, 0.2, 0.4, 0.2, 0.01);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
}
