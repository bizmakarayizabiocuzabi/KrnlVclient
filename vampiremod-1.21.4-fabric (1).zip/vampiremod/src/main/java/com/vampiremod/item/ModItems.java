package com.vampiremod.item;

import com.vampiremod.VampireMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public class ModItems {

    public static Item VAMPIRE_FANGS;
    public static Item BLOOD_VIAL;

    public static void register() {
        Identifier fangsId = Identifier.of(VampireMod.MOD_ID, "vampire_fangs");
        Identifier vialId = Identifier.of(VampireMod.MOD_ID, "blood_vial");

        VAMPIRE_FANGS = Registry.register(
            Registries.ITEM,
            fangsId,
            new VampireFangsItem(new Item.Settings()
                .registryKey(RegistryKey.of(RegistryKeys.ITEM, fangsId))
                .maxCount(1)
            )
        );

        BLOOD_VIAL = Registry.register(
            Registries.ITEM,
            vialId,
            new BloodVialItem(new Item.Settings()
                .registryKey(RegistryKey.of(RegistryKeys.ITEM, vialId))
                .maxCount(16)
            )
        );

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(VAMPIRE_FANGS);
            entries.add(BLOOD_VIAL);
        });

        VampireMod.LOGGER.info("ModItems registered.");
    }
}
