package com.vampiremod.effect;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.server.world.ServerWorld;

public class BloodThirstEffect extends StatusEffect {

    public BloodThirstEffect() {
        super(StatusEffectCategory.HARMFUL, 0x8B0000);
    }

    @Override
    public boolean applyUpdateEffect(ServerWorld world, LivingEntity entity, StatusEffectInstance effect, int amplifier, org.joml.Vector3f pos) {
        entity.damage(world.getDamageSources().starve(), 1.0f * (amplifier + 1));
        return true;
    }

    @Override
    public boolean canApplyUpdateEffect(StatusEffectInstance effect) {
        int j = 40 >> effect.getAmplifier();
        if (j > 0) {
            return effect.getDuration() % j == 0;
        }
        return true;
    }
}
