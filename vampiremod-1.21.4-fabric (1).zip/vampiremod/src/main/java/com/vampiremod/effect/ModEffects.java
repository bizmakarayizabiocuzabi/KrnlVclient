package com.vampiremod.effect;

import com.vampiremod.VampireMod;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

public class ModEffects {

    public static RegistryEntry<StatusEffect> BLOOD_THIRST;

    public static void register() {
        BLOOD_THIRST = Registry.registerReference(
            Registries.STATUS_EFFECT,
            Identifier.of(VampireMod.MOD_ID, "blood_thirst"),
            new BloodThirstEffect()
        );
        VampireMod.LOGGER.info("ModEffects kaydedildi.");
    }
}
