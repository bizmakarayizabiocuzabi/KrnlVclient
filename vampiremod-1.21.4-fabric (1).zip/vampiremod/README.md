# 🧛 VampireMod - Minecraft 1.21.4 Fabric Modu

## Özellikler

### 🩸 Vampir Sistemi
- **Irk Seçimi**: Oyun başında "İnsan mı Vampir mi?" ekranı gelir
- **Kan Metresi**: HUD'da sağ alt köşede görünür (0-100)
- **Kan Tükenmesi**: Her **3 dakikada** bir 20 kan azalır
- **Uyarılar**: Düşük kanda baş dönmesi, bulanık görüş, kırmızı ekran yanıp söner

### 🦷 Vampir Dişleri (Item)
- **Normal tıklama**: Köylüden kan iç (+30 kan)
- **Shift + tıklama**: Köylüyü vampir yap
- Diğer mobları ısırabilirsin (+15 kan)
- Harika parıltı efekti!

### 🧛 Vampir Köylü Entity
- Dönüştürülen köylü artık sana hizmet eder
- **Sağ tık** ile komut ekranı açılır:
  - ⚔ **Saldır** – En yakın köylüye saldırır
  - 🩸 **Kanını İçeyim mi?** – Efendisine sorar
  - 🧪 **Kan Getir** – Kan getirir
  - 🧛 **Vampir Yap** – Başka köylüyü vampir yapar
- Saldırdığında efendisine mesaj gönderir: *"Efendim! Kanını içeyim mi? Sanamı getireyim?"*
- Güneşte yanar!

### ☀️ Güneş Hasarı
- Vampirler açık havada gündüz ateş alır

### 🎨 Özel İçerik
- Özel HUD (Kan metresi + pulse efekti)
- Özel textureler (vampir dişleri, kan şişesi, vampir köylü skin)
- Özel sesler (ısırma, kan içme, dönüşüm, hiss)
- Özel GUI ekranları (Irk seçimi, Komut menüsü)
- Kırmızı ekran uyarı overlay efekti

---

## Kurulum (GitHub Codespaces)

```bash
# 1. Repoyu klonla veya zip'i aç
# 2. Kurulum scriptini çalıştır:
chmod +x setup.sh
./setup.sh
```

Script otomatik olarak:
1. Gradle wrapper jar'ı indirir
2. Bağımlılıkları çeker (Minecraft, Fabric API)
3. Modu build eder

---

## Manuel Build

```bash
# Gradle wrapper jar'ı indir (internet gerekli)
curl -L "https://github.com/gradle/gradle/raw/v8.10.2/gradle/wrapper/gradle-wrapper.jar" \
     -o gradle/wrapper/gradle-wrapper.jar

# Build
./gradlew build

# JAR çıktısı: build/libs/vampiremod-1.0.0.jar
```

---

## Gereksinimler
| Bileşen | Versiyon |
|---|---|
| Minecraft | 1.21.4 |
| Java | 21+ |
| Fabric Loader | 0.16.9 |
| Fabric API | 0.113.0+1.21.4 |

---

## Kullanım (Oyun İçi)

1. Oyunu başlat → Irk seçim ekranı gelir
2. **Vampir** seç → Kan metresi aktif olur
3. Yaratıcı modda `vampiremod:vampire_fangs` al
4. Bir köylüye sağ tıkla → Kan iç
5. Shift + sağ tıkla → Vampir yap
6. Vampir köylüye sağ tıkla → Komut ver

---

*Mod kaynağı: `src/main/java/com/vampiremod/`*
