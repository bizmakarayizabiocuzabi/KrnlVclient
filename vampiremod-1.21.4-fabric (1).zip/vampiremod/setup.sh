#!/bin/bash
set -e

echo "╔══════════════════════════════════════════╗"
echo "║        VampireMod Build Setup            ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── 1. Gerçek gradle-wrapper.jar indir ──────────────────────────────
JAR_PATH="gradle/wrapper/gradle-wrapper.jar"
JAR_MIN_SIZE=50000

download_jar() {
    local url="$1"
    echo "İndiriliyor: $url"
    curl -fsSL "$url" -o "$JAR_PATH" && {
        size=$(wc -c < "$JAR_PATH")
        if [ "$size" -gt "$JAR_MIN_SIZE" ]; then
            echo "✓ İndirildi ($size bytes)"
            return 0
        fi
    }
    return 1
}

if [ ! -s "$JAR_PATH" ] || [ "$(wc -c < "$JAR_PATH")" -lt "$JAR_MIN_SIZE" ]; then
    echo "► Gradle wrapper jar indiriliyor..."
    download_jar "https://github.com/gradle/gradle/raw/v8.10.2/gradle/wrapper/gradle-wrapper.jar" ||
    download_jar "https://raw.githubusercontent.com/gradle/gradle/v8.10.2/gradle/wrapper/gradle-wrapper.jar" ||
    download_jar "https://search.maven.org/remotecontent?filepath=gradle/gradle-wrapper/8.10.2/gradle-wrapper-8.10.2.jar" || {
        echo ""
        echo "⚠ Otomatik indirme başarısız!"
        echo "Manuel olarak şunu çalıştırın:"
        echo "  wget -O gradle/wrapper/gradle-wrapper.jar \\"
        echo "    'https://github.com/gradle/gradle/releases/download/v8.10.2/gradle-8.10.2-wrapper.jar'"
        echo ""
        echo "VEYA GitHub Codespaces'de:"
        echo "  sdk install gradle 8.10.2"
        echo "  gradle wrapper"
        exit 1
    }
else
    echo "✓ Gradle wrapper jar mevcut ($(wc -c < "$JAR_PATH") bytes)"
fi

# ── 2. gradlew çalıştırılabilir yap ─────────────────────────────────
chmod +x gradlew
echo "✓ gradlew izinleri ayarlandı"

# ── 3. Java kontrol ─────────────────────────────────────────────────
if ! command -v java &>/dev/null; then
    echo "⚠ Java bulunamadı! Java 21 yükleyin:"
    echo "  sudo apt-get install openjdk-21-jdk -y"
    exit 1
fi
JAVA_VER=$(java -version 2>&1 | grep -oP '(?<=version ")[^"]+' | head -1)
echo "✓ Java: $JAVA_VER"

# ── 4. Build ─────────────────────────────────────────────────────────
echo ""
echo "► Mod build ediliyor..."
echo "   (İlk build Minecraft ve Fabric bağımlılıklarını indirir, ~10-20 dk sürebilir)"
echo ""
./gradlew build --no-daemon

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║             BUILD TAMAMLANDI!            ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "► JAR dosyası:"
ls build/libs/*.jar 2>/dev/null | grep -v sources
echo ""
echo "► Bu JAR dosyasını Minecraft mods/ klasörüne kopyalayın."
echo "► Fabric Loader 0.16.9 ve Fabric API 0.113.0+1.21.4 gereklidir."
