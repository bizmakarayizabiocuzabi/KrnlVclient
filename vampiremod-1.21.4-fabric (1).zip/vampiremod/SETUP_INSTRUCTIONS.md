# VampireMod Kurulum Talimatları

## GitHub Codespaces'de Kurulum

### 1. Gradle Wrapper JAR İndir
```bash
# Otomatik kurulum scripti çalıştır
chmod +x setup.sh
./setup.sh
```

VEYA manuel olarak:
```bash
# Gradle wrapper jar'ı indir
curl -L "https://github.com/gradle/gradle/raw/v8.10.2/gradle/wrapper/gradle-wrapper.jar" \
     -o gradle/wrapper/gradle-wrapper.jar
```

### 2. Build Et
```bash
./gradlew build
```

### 3. JAR Dosyası
`build/libs/vampiremod-1.0.0.jar` dosyasını Minecraft `mods` klasörüne kopyala.

## Gereksinimler
- Java 21+
- Fabric Loader 0.16.9
- Fabric API 0.113.0+1.21.4
- Minecraft 1.21.4

## Özellikler
- 🧛 Oyun başında İnsan/Vampir seçimi
- 🩸 Kan metresi HUD (3 dakikada bir azalır)
- 🦷 Vampir Dişleri item (köylüleri ısır)
- 💀 Vampir Köylü entity (komut verme sistemi)
- ☀️ Güneş hasarı vampirlere
- 😵 Düşük kanda baş dönmesi ve bulanık görüş
- 🎨 Özel texture, GUI, ses efektleri
